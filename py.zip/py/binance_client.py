import os
from binance.client import Client
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class BinanceClient:
    def __init__(self):
        self.client = Client(
            api_key=os.getenv('BINANCE_API_KEY'),
            api_secret=os.getenv('BINANCE_API_SECRET')
        )

    def get_market_price(self, symbol):
        """Fetch the current market price for a symbol."""
        ticker = self.client.get_symbol_ticker(symbol=symbol)
        return float(ticker['price'])

    def place_order(self, symbol, side, quantity, order_type='MARKET'):
        """Place an order on Binance."""
        order = self.client.create_order(
            symbol=symbol,
            side=side,
            type=order_type,
            quantity=quantity
        )
        return order
