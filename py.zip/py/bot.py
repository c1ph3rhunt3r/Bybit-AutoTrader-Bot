import re
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters, CallbackContext
from dotenv import load_dotenv
import os
import logging
from bybit_client import BybitClient

# Load environment variables
load_dotenv()

TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')

# Initialize logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Bybit client
bybit_client = BybitClient()

# Global variable to keep track of the current mode
current_mode = "Manual"  # Default mode

async def start(update: Update, context: CallbackContext) -> None:
    """Send a welcome message and show mode options."""
    keyboard = [
        [InlineKeyboardButton("Manual Mode", callback_data='manual')],
        [InlineKeyboardButton("Signal Mode", callback_data='signal')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Welcome to the Automated Trading Bot! Choose your mode:', reply_markup=reply_markup)

async def button(update: Update, context: CallbackContext) -> None:
    """Handle button presses for mode selection."""
    query = update.callback_query
    await query.answer()

    global current_mode
    if query.data == 'manual':
        current_mode = "Manual"
        await query.edit_message_text(text="Manual Mode activated. You can now place trades manually.")
    elif query.data == 'signal':
        current_mode = "Signal"
        await query.edit_message_text(text="Signal Mode activated. The bot will listen for trade signals in this chat.")

async def handle_message(update: Update, context: CallbackContext) -> None:
    """Handle incoming messages depending on the current mode."""
    global current_mode
    if current_mode == "Manual":
        await handle_manual_trade(update, context)
    elif current_mode == "Signal":
        await handle_signal_trade(update, context)

def parse_trade_signal(text):
    """Parse trade signal text and return relevant details."""
    lines = text.splitlines()
    symbol_side = lines[0].strip()  # First line is the trading pair with side, e.g., ETHUSDT (LONG)
    
    # Extract symbol and side
    symbol_match = re.match(r"(\w+)\s*\((LONG|SHORT)\)", symbol_side)
    if symbol_match:
        symbol = symbol_match.group(1)
        side = "Buy" if symbol_match.group(2) == "LONG" else "Sell"
    else:
        return None, None, None, None, None, None, None

    entry = sl = leverage = None
    tps = []
    quantity = 0.25  # Default to 25% if not specified

    for line in lines[1:]:
        if "Entry:" in line:
            entry = float(line.split(":")[1].strip())
        elif "SL:" in line:
            sl = float(line.split(":")[1].strip())
        elif "TP" in line:
            tp_value = float(line.split(":")[1].strip())
            tps.append(tp_value)
        elif "Leverage:" in line:
            leverage_match = re.search(r"Leverage:\s*(\d+)x", line)
            if leverage_match:
                leverage = int(leverage_match.group(1))
        elif "Quantity:" in line:
            quantity_str = line.split(":")[1].strip()
            if "%" in quantity_str:
                # Handle percentage-based quantity
                percentage = float(quantity_str.strip('%'))
                quantity = calculate_quantity_from_percentage(symbol, percentage)
            else:
                # Handle fixed quantity
                quantity = float(quantity_str)
    
    # Default leverage if not provided
    if leverage is None:
        leverage = 10  # Default to 10x

    # If no TP is provided, return a single TP as the entry point (though typically TP should be provided)
    if not tps:
        tps = [entry]

    return symbol, side, entry, sl, tps, leverage, quantity

def calculate_quantity_from_percentage(symbol, percentage):
    """Calculate the trade quantity based on the percentage of available balance."""
    balance_info = bybit_client.get_balance(symbol.split('/')[0])
    balance = balance_info['total']  # Adjust based on API response structure
    quantity = (percentage / 100) * balance
    return quantity

async def handle_signal_trade(update: Update, context: CallbackContext) -> None:
    """Handle trade signals in Signal Mode."""
    text = update.message.text
    symbol, side, entry, sl, tps, leverage, quantity = parse_trade_signal(text)

    if symbol and side and entry and sl and tps and leverage and quantity:
        # Place a trade for each TP
        for i, tp in enumerate(tps):
            response = bybit_client.place_order(
                symbol=symbol,
                side=side,
                qty=quantity,  # Use the calculated or parsed quantity
                order_type='Limit' if i < len(tps) - 1 else 'Market',  # Limit for TPs, Market for final TP
                price=tp if i < len(tps) - 1 else None,  # Price only for limit orders
                time_in_force="GoodTillCancel"
            )
            await update.message.reply_text(f"Trade placed: {side} {symbol} at Entry: {entry} with SL: {sl}, TP: {tp}, Leverage: {leverage}x, Quantity: {quantity}")
    else:
        await update.message.reply_text("Error: Could not parse signal. Ensure it follows the correct format.")

async def handle_manual_trade(update: Update, context: CallbackContext) -> None:
    """Handle manual trade placement."""
    text = update.message.text
    symbol, side, tp, sl, leverage, quantity = parse_trade_signal(text)

    if symbol and leverage and quantity:
        response = bybit_client.place_order(
            symbol=symbol,
            side=side,  # Or determine side based on input
            qty=quantity,  # Use the calculated or parsed quantity
            order_type='Market'
        )
        await update.message.reply_text(f"Manual trade command received: {side} {symbol} with TP: {tp}, SL: {sl}, Leverage: {leverage}x, Quantity: {quantity}")
    else:
        await update.message.reply_text("Error: Could not parse manual trade. Ensure it follows the correct format.")

async def main():
    """Start the bot."""
    application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()

    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Run the bot until manually stopped
    await application.run_polling()

if __name__ == '__main__':
    try:
        # Check if there's an existing event loop running
        loop = asyncio.get_running_loop()
    except RuntimeError:  # No loop is running, so create a new one
        loop = None

    if loop and loop.is_running():
        # If a loop is running, we simply create a task for the main function
        print("Async event loop is already running. Running main() in it.")
        loop.create_task(main())
        # Prevent the script from exiting immediately
        loop.run_forever()
    else:
        # No event loop is running, so start a new one
        asyncio.run(main())
