from bybit import bybit
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class BybitClient:
    def __init__(self):
        self.client = bybit(
            test=False,
            api_key=os.getenv('BYBIT_API_KEY'),
            api_secret=os.getenv('BYBIT_API_SECRET')
        )

    def get_balance(self, currency):
        """Fetch the balance of a specific currency."""
        wallet_balance = self.client.Wallet.Wallet_getBalance(coin=currency).result()
        return wallet_balance['result'][currency]

    def place_order(self, symbol, side, qty, order_type='Market', price=None, time_in_force="GoodTillCancel"):
        """Place an order on Bybit."""
        if order_type == 'Limit':
            order = self.client.Order.Order_new(
                side=side,
                symbol=symbol,
                order_type=order_type,
                qty=qty,
                price=price,
                time_in_force=time_in_force
            ).result()
        else:
            order = self.client.Order.Order_new(
                side=side,
                symbol=symbol,
                order_type=order_type,
                qty=qty,
                time_in_force="GoodTillCancel"
            ).result()
        return order
